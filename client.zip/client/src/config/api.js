const configuredApiUrl = import.meta.env.VITE_API_URL?.trim();

if (!configuredApiUrl) {
  throw new Error("Thiếu biến môi trường VITE_API_URL.");
}

export const API_BASE_URL = configuredApiUrl.replace(/\/+$/, "");

export const apiUrl = (path = "") => {
  const normalizedPath = String(path).replace(/^\/+/, "");

  return normalizedPath ? `${API_BASE_URL}/${normalizedPath}` : API_BASE_URL;
};
