import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import {
  FaCreditCard,
  FaExclamationTriangle,
  FaHome,
  FaReceipt,
  FaSyncAlt,
} from "react-icons/fa";
import { API_BASE_URL } from "../config/api";
import "./CheckoutFailedPage.css";

const FAILURE_MESSAGES = {
  "07": "Giao dịch bị nghi ngờ gian lận.",
  "09": "Thẻ hoặc tài khoản chưa đăng ký dịch vụ Internet Banking.",
  "10": "Bạn đã nhập sai thông tin xác thực quá số lần cho phép.",
  "11": "Giao dịch đã hết thời gian thanh toán.",
  "12": "Thẻ hoặc tài khoản đang bị khóa.",
  "13": "Mã xác thực OTP không chính xác.",
  "24": "Bạn đã hủy giao dịch thanh toán.",
  "51": "Tài khoản không đủ số dư để thanh toán.",
  "65": "Tài khoản đã vượt quá hạn mức giao dịch trong ngày.",
  "75": "Ngân hàng thanh toán đang bảo trì.",
  "79": "Bạn đã nhập sai mật khẩu thanh toán quá số lần cho phép.",
  invalid_signature: "Không thể xác minh chữ ký phản hồi từ VNPay.",
  system_error: "Hệ thống gặp lỗi khi xử lý kết quả thanh toán.",
  unknown: "VNPay chưa xác nhận giao dịch thành công.",
};

const PAYMENT_STATUS_LABELS = {
  paid: "Đã thanh toán",
  pending: "Chờ thanh toán",
  unpaid: "Chưa thanh toán",
  failed: "Thanh toán thất bại",
  expired: "Đã hết hạn thanh toán",
  refunded: "Đã hoàn tiền",
};

const firstValidationMessage = (data) =>
  data?.errors ? Object.values(data.errors).flat().find(Boolean) : null;

const formatMoney = (value) => {
  const amount = Number(value);
  return Number.isFinite(amount)
    ? `${amount.toLocaleString("vi-VN")} đ`
    : "—";
};

export default function CheckoutFailedPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const rawOrderId = searchParams.get("order_id")?.trim() || "";
  const orderId = useMemo(
    () => (/^[1-9]\d*$/.test(rawOrderId) ? rawOrderId : null),
    [rawOrderId]
  );
  const reason =
    searchParams.get("reason") ||
    searchParams.get("vnp_ResponseCode") ||
    "unknown";

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const requestVersionRef = useRef(0);
  const activeControllerRef = useRef(null);
  const paymentLockRef = useRef(false);

  const getHeaders = useCallback(() => {
    const token =
      localStorage.getItem("access_token") || localStorage.getItem("token");

    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token.trim()}` } : {}),
    };
  }, []);

  const forceLogin = useCallback(() => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("token");
    localStorage.removeItem("user_info");
    navigate("/login", { replace: true });
  }, [navigate]);

  const loadOrder = useCallback(
    async ({ silent = false } = {}) => {
      if (!orderId) {
        setOrder(null);
        setError(
          rawOrderId
            ? "Mã đơn hàng trên đường dẫn không hợp lệ."
            : "Đường dẫn không có mã đơn hàng để kiểm tra."
        );
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const token =
        localStorage.getItem("access_token") || localStorage.getItem("token");
      if (!token) {
        forceLogin();
        return;
      }

      activeControllerRef.current?.abort();
      const controller = new AbortController();
      activeControllerRef.current = controller;
      const requestVersion = ++requestVersionRef.current;

      if (silent) setRefreshing(true);
      else setLoading(true);

      try {
        const response = await fetch(
          `${API_BASE_URL}/orders/${encodeURIComponent(orderId)}`,
          {
            headers: getHeaders(),
            signal: controller.signal,
          }
        );
        const data = await response.json().catch(() => ({}));

        if (requestVersion !== requestVersionRef.current) return;

        if (response.status === 401) {
          forceLogin();
          return;
        }

        if (response.status === 404) {
          setOrder(null);
          setError(
            "Không tìm thấy đơn hàng này hoặc đơn hàng không thuộc tài khoản của bạn."
          );
          return;
        }

        if (!response.ok || data.status === false) {
          throw new Error(
            firstValidationMessage(data) ||
              data.message ||
              "Không thể kiểm tra đơn hàng."
          );
        }

        const currentOrder = data.order || data.data || data;
        if (!currentOrder?.id) {
          throw new Error("Dữ liệu đơn hàng từ máy chủ không hợp lệ.");
        }

        setError("");
        setNotice("");
        setOrder(currentOrder);

        // IPN có thể về chậm hơn trình duyệt. Nếu database đã ghi nhận thanh
        // toán thì không tiếp tục hiển thị trang thất bại.
        if (currentOrder.payment_status === "paid") {
          navigate(
            `/order-success?order_id=${encodeURIComponent(
              currentOrder.id
            )}&payment=vnpay`,
            { replace: true }
          );
        }
      } catch (requestError) {
        if (requestError.name === "AbortError") return;
        if (requestVersion !== requestVersionRef.current) return;

        console.error("Không thể kiểm tra đơn hàng:", requestError);
        setOrder(null);
        setError(
          requestError.message || "Không thể kết nối máy chủ để kiểm tra đơn hàng."
        );
      } finally {
        if (requestVersion === requestVersionRef.current) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    }, [forceLogin, getHeaders, navigate, orderId, rawOrderId]
  );

  useEffect(() => {
    loadOrder();

    const refreshWhenVisible = () => {
      if (document.visibilityState === "visible") {
        loadOrder({ silent: true });
      }
    };

    const refreshWhenFocused = () => loadOrder({ silent: true });

    document.addEventListener("visibilitychange", refreshWhenVisible);
    window.addEventListener("focus", refreshWhenFocused);

    return () => {
      requestVersionRef.current += 1;
      activeControllerRef.current?.abort();
      document.removeEventListener("visibilitychange", refreshWhenVisible);
      window.removeEventListener("focus", refreshWhenFocused);
    };
  }, [loadOrder]);

  const retryPayment = async () => {
    if (!order?.id || paymentLockRef.current) return;

    if (order.payment_method !== "vnpay") {
      setNotice("Đơn hàng này không sử dụng phương thức VNPay.");
      return;
    }

    if (order.status === "cancelled") {
      setNotice("Đơn hàng đã bị hủy nên không thể thanh toán lại.");
      return;
    }

    if (order.status === "completed" || order.payment_status === "paid") {
      await loadOrder({ silent: true });
      return;
    }

    paymentLockRef.current = true;
    setPaying(true);
    setNotice("");

    try {
      const response = await fetch(`${API_BASE_URL}/vnpay/create`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({ order_id: order.id }),
      });
      const data = await response.json().catch(() => ({}));

      if (response.status === 401) {
        forceLogin();
        return;
      }

      const paymentUrl = data.url || data.payment_url || data.data?.url || data.data;
      if (!response.ok || typeof paymentUrl !== "string") {
        throw new Error(
          firstValidationMessage(data) ||
            data.message ||
            "Không thể tạo liên kết VNPay mới."
        );
      }

      window.location.assign(paymentUrl);
    } catch (paymentError) {
      console.error("Không thể thanh toán lại:", paymentError);
      setNotice(
        paymentError.message || "Không thể tạo liên kết thanh toán VNPay mới."
      );
      paymentLockRef.current = false;
      setPaying(false);
      await loadOrder({ silent: true });
    }
  };

  const canRetry =
    order?.payment_method === "vnpay" &&
    order?.payment_status !== "paid" &&
    !["cancelled", "completed"].includes(order?.status);

  const failureMessage = FAILURE_MESSAGES[reason] || FAILURE_MESSAGES.unknown;

  if (loading) {
    return (
      <div className="checkout-failed-page checkout-failed-page--center">
        <div className="checkout-failed-state-card">
          <FaSyncAlt className="checkout-failed-spinner checkout-failed-spin" />
          <h1 className="checkout-failed-state-title">
            Đang kiểm tra đơn hàng
          </h1>
          <p className="checkout-failed-state-text">
            Hệ thống đang đối chiếu trạng thái mới nhất từ máy chủ.
          </p>
        </div>
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="checkout-failed-page checkout-failed-page--center">
        <main className="checkout-failed-state-card checkout-failed-state-card--error">
          <div className="checkout-failed-icon checkout-failed-icon--error">
            <FaExclamationTriangle />
          </div>
          <span className="checkout-failed-kicker">THÔNG TIN ĐƠN HÀNG</span>
          <h1 className="checkout-failed-state-title">
            Không thể xác minh đơn hàng
          </h1>
          <p className="checkout-failed-state-text">{error}</p>
          <div className="checkout-failed-actions">
            <Link
              to="/orders"
              className="checkout-failed-button checkout-failed-button--primary"
            >
              <FaReceipt /> Xem đơn hàng của tôi
            </Link>
            <Link
              to="/"
              className="checkout-failed-button checkout-failed-button--secondary"
            >
              <FaHome /> Về trang chủ
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="checkout-failed-page">
      <main className="checkout-failed-container">
        <div className="checkout-failed-icon checkout-failed-icon--error">
          <FaExclamationTriangle />
        </div>

        <span className="checkout-failed-kicker">KẾT QUẢ THANH TOÁN</span>
        <h1 className="checkout-failed-title">
          Thanh toán chưa thành công
        </h1>
        <p className="checkout-failed-description">
          {failureMessage} Trạng thái bên dưới đã được đối chiếu trực tiếp với
          đơn hàng của bạn.
        </p>

        <div className="checkout-failed-order-card">
          <div className="checkout-failed-order-card__head">
            <div>
              <span>ĐƠN HÀNG</span>
              <strong>#{order.id}</strong>
            </div>
            <span className="checkout-failed-status-badge">
              {PAYMENT_STATUS_LABELS[order.payment_status] ||
                order.payment_status ||
                "Chưa xác định"}
            </span>
          </div>

          <div className="checkout-failed-detail-row">
            <span>Phương thức thanh toán</span>
            <strong>
              {order.payment_method === "vnpay" ? "VNPay" : "COD"}
            </strong>
          </div>
          <div className="checkout-failed-detail-row">
            <span>Trạng thái thanh toán</span>
            <strong className="checkout-failed-detail-row__danger">
              {PAYMENT_STATUS_LABELS[order.payment_status] ||
                order.payment_status ||
                "Chưa xác định"}
            </strong>
          </div>
          <div className="checkout-failed-detail-row checkout-failed-detail-row--total">
            <span>Tổng thanh toán</span>
            <strong>
              {formatMoney(order.total_amount)}
            </strong>
          </div>
        </div>

        {notice && (
          <div className="checkout-failed-notice">
            {notice}
          </div>
        )}

        <div className="checkout-failed-actions">
          {canRetry && (
            <button
              type="button"
              onClick={retryPayment}
              disabled={paying || refreshing}
              className="checkout-failed-button checkout-failed-button--primary"
            >
              <FaCreditCard />
              {paying ? "Đang mở VNPay..." : "Thanh toán lại"}
            </button>
          )}

          <Link
            to="/orders"
            className="checkout-failed-button checkout-failed-button--secondary"
          >
            <FaReceipt /> Xem đơn hàng
          </Link>

          <button
            type="button"
            onClick={() => loadOrder({ silent: true })}
            disabled={refreshing || paying}
            className="checkout-failed-button checkout-failed-button--outline checkout-failed-button--compact"
          >
            <FaSyncAlt className={refreshing ? "checkout-failed-spin" : ""} />
            {refreshing ? "Đang kiểm tra" : "Kiểm tra lại"}
          </button>
        </div>
      </main>
    </div>
  );
}
