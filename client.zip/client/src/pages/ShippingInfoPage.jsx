import { Link } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import Footer from "../components/Footer";
import { useFriendCheckoutLogic } from "../services/useFriendCheckoutLogic";
import "./CheckoutPage.css";

export default function ShippingInfoPage() {
  const {
    form, errors, savedAddresses, selectedAddressId, handleSelectAddress,
    cartItems, loading, showVoucherModal, setShowVoucherModal,
    isLoadingCoupons, openVoucherModal,
    voucherTab, setVoucherTab, inputVoucher, setInputVoucher, dbCoupons,
    appliedProductVoucher, setAppliedProductVoucher,
    appliedShippingVoucher, setAppliedShippingVoucher,
    isApplying, surname, setSurname, wardDistrict, setWardDistrict,

    note, setNote,
    shippingMethod, setShippingMethod, checkoutPayment, setCheckoutPayment,

    handleApplyCoupon, handleChange, handleSubmit,
    subtotal, baseShippingFee, productDiscount, shippingDiscount,
    finalShippingFee, total, provinces, wards,
    handleProvinceChange, handleWardChange, retryMode, notice,
    submitting, isQuoteLoading,
 } = useFriendCheckoutLogic();

const totalQuantity = cartItems.reduce(
  (sum, item) => sum + Number(item.quantity || 0),
  0
);

const visibleCoupons = dbCoupons.filter((coupon) => {
  if (voucherTab === "shipping") {
    return coupon.discount_type === "shipping";
  }

  return coupon.discount_type !== "shipping";
});

  return (
    <div className="ash-checkout-page">
      <Toaster position="top-right" />



      <main className="ash-checkout-main">
        <div className="ash-checkout-shell">
          {/* ================= CỘT TRÁI ================= */}
          <section className="ash-checkout-left">
            <div className="ash-checkout-content">
              {notice && (
                <div className="ash-checkout-api-notice">{notice}</div>
              )}
              {/* Thông tin giao hàng */}
              <section className="ash-checkout-section">
                <h2>
                  Thông Tin Giao Hàng{" "}
                  <span>(Địa chỉ SAU SÁP NHẬP)</span>
                </h2>

                {!retryMode && (
                  <div className="ash-checkout-field">
                    <select
                      value={selectedAddressId}
                      onChange={handleSelectAddress}
                    >
                      <option value="">+ Nhập địa chỉ mới</option>
                      {savedAddresses.map((address) => (
                        <option key={address.id} value={address.id}>
                          {address.receiver_name} — {address.street}, {address.ward}, {address.province}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="ash-checkout-two-cols">
                  <div className="ash-checkout-field">
                    <input
                      type="text"
                      value={surname}
                      onChange={(event) => setSurname(event.target.value)}
                      placeholder="Họ"
                    />
                  </div>

                  <div className="ash-checkout-field">
                    <input
                      type="text"
                      value={form.name}
                      onChange={handleChange("name")}
                      placeholder="Tên người nhận"
                      className={errors.name ? "is-error" : ""}
                    />
                    {errors.name && (
                      <p className="ash-checkout-error">{errors.name}</p>
                    )}
                  </div>
                </div>

                <div className="ash-checkout-field">
                  <div className="ash-checkout-input-wrap">
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={handleChange("phone")}
                      placeholder="Số điện thoại"
                      className={errors.phone ? "is-error" : ""}
                    />
                    <span className="ash-checkout-input-icon">?</span>
                  </div>
                  {errors.phone && (
                    <p className="ash-checkout-error">{errors.phone}</p>
                  )}
                </div>

                <div className="ash-checkout-field">
                  <select
                    value={form.province_code}
                    onChange={handleProvinceChange}
                    disabled={Boolean(selectedAddressId)}
                    className={errors.city ? "is-error" : ""}
                  >
                    <option value="">TỈNH / THÀNH PHỐ</option>
                    {provinces.map((province) => (
                      <option key={province.code} value={province.code}>
                        {province.name}
                      </option>
                    ))}
                  </select>
                  {errors.city && (
                    <p className="ash-checkout-error">{errors.city}</p>
                  )}
                </div>

                <div className="ash-checkout-field">
                  <select
                    value={form.ward_code}
                    onChange={handleWardChange}
                    disabled={Boolean(selectedAddressId) || !form.province_code}
                    className={errors.ward ? "is-error" : ""}
                  >
                    <option value="">PHƯỜNG / XÃ</option>
                    {selectedAddressId && form.ward_code && (
                      <option value={form.ward_code}>{wardDistrict}</option>
                    )}
                    {wards.map((ward) => (
                      <option key={ward.code} value={ward.code}>
                        {ward.name}
                      </option>
                    ))}
                  </select>
                  {errors.ward && (
                    <p className="ash-checkout-error">{errors.ward}</p>
                  )}
                </div>

                <div className="ash-checkout-field">
                  <input
                    type="text"
                    value={form.address}
                    onChange={handleChange("address")}
                    placeholder="Số nhà + tên đường"
                    className={errors.address ? "is-error" : ""}
                  />
                  {errors.address && (
                    <p className="ash-checkout-error">{errors.address}</p>
                  )}
                </div>
              </section>

              {/* Phương thức vận chuyển */}
              <section className="ash-checkout-section">
                <h3>Phương thức vận chuyển</h3>

                <div className="ash-checkout-option-box">
                  <label
                    className={`ash-checkout-option ${
                      shippingMethod === "economy"
                        ? "active"
                        : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="shippingMethod"
                      checked={shippingMethod === "economy"}
                      onChange={() =>
                        setShippingMethod("economy")
                      }
                    />
                    <span className="ash-radio-ui" />
                    <span className="ash-option-copy">
                      <strong>
                        Freeship - TikiNOW giao hàng từ 3 - 8 ngày
                        làm việc cho đơn từ 3,399,000Đ
                      </strong>
                    </span>
                    <b>
                      {subtotal >= 3399000
                        ? "MIỄN PHÍ"
                        : `${new Intl.NumberFormat("vi-VN").format(
                            30000
                          )} đ`}
                    </b>
                  </label>

                  <label
                    className={`ash-checkout-option ${
                      shippingMethod === "standard"
                        ? "active"
                        : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="shippingMethod"
                      checked={shippingMethod === "standard"}
                      onChange={() =>
                        setShippingMethod("standard")
                      }
                    />
                    <span className="ash-radio-ui" />
                    <span className="ash-option-copy">
                      <strong>
                        TikiNOW - Giao Hàng Tiêu Chuẩn 2-7 ngày làm
                        việc tùy tỉnh thành
                      </strong>
                    </span>
                    <b>50.000 đ</b>
                  </label>

                  <label
                    className={`ash-checkout-option ${
                      shippingMethod === "express"
                        ? "active"
                        : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="shippingMethod"
                      checked={shippingMethod === "express"}
                      onChange={() =>
                        setShippingMethod("express")
                      }
                    />
                    <span className="ash-radio-ui" />
                    <span className="ash-option-copy">
                      <strong>
                        Giao Hàng Grab Hỏa Tốc (Chỉ áp dụng nội thành
                        HCM) trước 16h ngày trong tuần
                      </strong>
                      <small>
                        Liên hệ CSKH để được hỗ trợ cụ thể về phí ship
                        và cách thức thanh toán
                      </small>
                    </span>
                    <b>200.000 đ</b>
                  </label>
                </div>
              </section>

              {/* Thanh toán */}
              <section className="ash-checkout-section">
                <h3>Thanh toán</h3>
                <p className="ash-checkout-muted">
                  Toàn bộ các giao dịch được bảo mật và mã hóa.
                </p>

                <div className="ash-checkout-option-box ash-payment-box">
                  <label
                    className={`ash-checkout-option ${
                      checkoutPayment === "vnpay" ? "active" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentOption"
                      checked={checkoutPayment === "vnpay"}
                      onChange={() =>
                        setCheckoutPayment("vnpay")
                      }
                    />
                    <span className="ash-radio-ui" />
                    <span className="ash-option-copy">
                      <strong>
                        VNPay - Thẻ ATM/QR/Ngân hàng
                      </strong>
                    </span>
                    <span className="ash-payment-logos" aria-label="Phương thức thanh toán hỗ trợ">
                      <span className="payment-logo payment-logo-visa">VISA</span>
                      <span className="payment-logo payment-logo-mastercard" aria-label="Mastercard">
                        <span className="mc-circle mc-red" />
                        <span className="mc-circle mc-orange" />
                      </span>
                      <span className="payment-logo payment-logo-jcb" aria-label="JCB">
                        <span>J</span><span>C</span><span>B</span>
                      </span>
                      <span className="payment-logo payment-logo-more">+2</span>
                    </span>
                  </label>

                  {checkoutPayment === "vnpay" && (
                    <div className="ash-payment-description">
                      Bạn sẽ được chuyển đến cổng thanh toán VNPay để hoàn tất giao dịch.
                    </div>
                  )}

                  <label
                    className={`ash-checkout-option ${
                      checkoutPayment === "cod" ? "active" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentOption"
                      checked={checkoutPayment === "cod"}
                      onChange={() => setCheckoutPayment("cod")}
                    />
                    <span className="ash-radio-ui" />
                    <span className="ash-option-copy">
                      <strong>
                        Thanh toán khi nhận hàng (COD)
                      </strong>
                    </span>
                  </label>

                </div>
              </section>

              <section className="ash-checkout-section">
                <h3>Ghi chú đơn hàng</h3>
                <textarea
                  className="ash-checkout-note"
                  value={note}
                  onChange={(event) => setNote(event.target.value)}
                  maxLength={500}
                  placeholder="Ví dụ: Gọi trước khi giao hàng"
                />
              </section>

              <button
                type="button"
                className="ash-checkout-pay-now"
                onClick={handleSubmit}
                disabled={
                  submitting ||
                  isQuoteLoading ||
                  (!retryMode && !total)
                }
              >
                {submitting
                  ? "ĐANG XỬ LÝ..."
                  : checkoutPayment === "cod"
                    ? "ĐẶT HÀNG COD"
                    : "THANH TOÁN QUA VNPAY"}
              </button>

              <footer className="ash-checkout-mini-footer">
                <Link to="/">Chính sách hoàn tiền</Link>
                <Link to="/">Vận chuyển</Link>
                <Link to="/">Chính sách quyền riêng tư</Link>
                <Link to="/">Điều khoản dịch vụ</Link>
                <Link to="/contact">Liên hệ</Link>
              </footer>
            </div>
          </section>

          {/* ================= CỘT PHẢI ================= */}
          <aside className="ash-checkout-right">
            <div className="ash-order-summary">
              <div className="ash-order-products">
                {loading ? (
                  <div
                    className="ash-order-skeleton-list"
                    aria-label="Đang tải đơn hàng"
                  >
                    {[0, 1, 2].map((item) => (
                      <div
                        className="ash-order-item ash-order-item-skeleton"
                        key={item}
                      >
                        <span className="ash-order-skeleton-thumb" />
                        <span className="ash-order-skeleton-copy" />
                        <span className="ash-order-skeleton-price" />
                      </div>
                    ))}
                  </div>
                ) : cartItems.length > 0 ? (
                  cartItems.map((item, index) => {
                    const product =
                      item.product_variant?.product || {};
                    const lineTotal =
                      Number(
                        item.price ||
                          product.current_price ||
                          product.sale_price ||
                          product.price ||
                          0
                      ) *
                      Number(item.quantity || 0);

                    return (
                      <div
                        key={item.id || index}
                        className="ash-order-item"
                      >
                        <div className="ash-order-thumb">
                          <img
                            src={
                              item.product_variant?.image_url ||
                              item.product_variant?.image ||
                              product.thumbnail ||
                              product.image_url ||
                              product.images?.[0]?.image_url ||
                              product.images?.[0]?.image_path ||
                              "/images/placeholder.png"
                            }
                            alt={product.name || "Sản phẩm"}
                            onError={(event) => {
                              event.currentTarget.onerror = null;
                              event.currentTarget.src =
                                "/images/placeholder.png";
                            }}
                          />
                          <span>{item.quantity}</span>
                        </div>

                        <div className="ash-order-item-info">
                          <strong>{product.name}</strong>
                          <small>
                            {item.product_variant?.color || ""}
                            {item.product_variant?.color &&
                            item.product_variant?.size
                              ? " / "
                              : ""}
                            {item.product_variant?.size || ""}
                          </small>

                          {appliedProductVoucher && (
                            <em>
                              ◇ {appliedProductVoucher.code} - đã áp
                              dụng ưu đãi
                            </em>
                          )}
                        </div>

                        <div className="ash-order-line-price">
                          {new Intl.NumberFormat("vi-VN").format(
                            lineTotal
                          )}{" "}
                          đ
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="ash-order-loading">
                    Giỏ hàng trống
                  </div>
                )}
              </div>

              {!retryMode && (
                <>
                  <div className="ash-order-coupon">
                    <input
                      type="text"
                      placeholder="Mã giảm giá hoặc thẻ quà tặng"
                      value={inputVoucher}
                      onChange={(e) => setInputVoucher(e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => handleApplyCoupon()}
                      disabled={isApplying}
                    >
                      {isApplying ? "Đang xử lý" : "Áp dụng"}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={openVoucherModal}
                    disabled={isLoadingCoupons}
                    style={{
                      width: "100%",
                      minHeight: "44px",
                      margin: "-14px 0 26px",
                      border: "1px solid #222",
                      borderRadius: "7px",
                      background: "#fff",
                      color: "#222",
                      fontSize: "12px",
                      fontWeight: 600,
                      cursor: isLoadingCoupons
                        ? "wait"
                        : "pointer",
                      opacity: isLoadingCoupons ? 0.65 : 1,
                    }}
                  >
                    {isLoadingCoupons
                      ? "ĐANG TẢI ƯU ĐÃI..."
                      : "CHỌN MÃ GIẢM GIÁ"}
                  </button>
                </>
              )}

              <div className="ash-order-totals">
                <div>
                  <span>
                    Tổng phụ
                    {totalQuantity > 1
                      ? ` · ${totalQuantity} mặt hàng`
                      : ""}
                  </span>
                  <b>
                    {new Intl.NumberFormat("vi-VN").format(
                      subtotal
                    )}{" "}
                    đ
                  </b>
                </div>

                <div>
                  <span>Vận chuyển ⓘ</span>
                  <b>
                    {finalShippingFee === 0
                      ? "MIỄN PHÍ"
                      : `${new Intl.NumberFormat("vi-VN").format(
                          finalShippingFee
                        )} đ`}
                  </b>
                </div>

                {productDiscount > 0 && (
                  <div className="ash-order-discount">
                    <span>Giảm giá sản phẩm</span>
                    <b>
                      -
                      {new Intl.NumberFormat("vi-VN").format(
                        productDiscount
                      )}{" "}
                      đ
                    </b>
                  </div>
                )}

                {shippingDiscount > 0 && (
                  <div className="ash-order-discount">
                    <span>Giảm phí vận chuyển</span>
                    <b>
                      -
                      {new Intl.NumberFormat("vi-VN").format(
                        shippingDiscount
                      )}{" "}
                      đ
                    </b>
                  </div>
                )}
              </div>

              <div className="ash-order-grand-total">
                <div>
                  <strong>Tổng</strong>
                  <small>
                    Bao gồm thuế theo chính sách hiện hành
                  </small>
                </div>

                <div>
                  <span>VND</span>
                  <b>
                    {isQuoteLoading
                      ? "Đang tính..."
                      : `${new Intl.NumberFormat("vi-VN").format(
                          total
                        )} đ`}
                  </b>
                </div>
              </div>

              {(productDiscount > 0 || shippingDiscount > 0) && (
                <div className="ash-order-saved">
                  ◇ TỔNG SỐ TIỀN TIẾT KIỆM ĐƯỢC{" "}
                  {new Intl.NumberFormat("vi-VN").format(
                    productDiscount + shippingDiscount
                  )}{" "}
                  đ
                </div>
              )}
            </div>
          </aside>
        </div>
      </main>

      {/* POPUP MÃ GIẢM GIÁ - giữ nguyên logic hiện tại */}
      {showVoucherModal && (
        <div className="voucher-modal-overlay">
          <div className="voucher-modal-box">
            <div className="voucher-modal-header">
              <h3>MÃ GIẢM GIÁ & ƯU ĐÃI</h3>
              <button
                type="button"
                className="close-btn"
                onClick={() => setShowVoucherModal(false)}
              >
                ✕
              </button>
            </div>

            <div className="voucher-input-group">
              <input
                type="text"
                placeholder="Nhập mã giảm giá của bạn"
                value={inputVoucher}
                onChange={(e) => setInputVoucher(e.target.value)}
              />
              <button
                type="button"
                onClick={() => handleApplyCoupon()}
                disabled={isApplying}
              >
                {isApplying ? "Đang ktra..." : "ÁP DỤNG"}
              </button>
            </div>

            <div className="voucher-tabs">
              <button
                type="button"
                className={
                  voucherTab === "product" ? "active" : ""
                }
                onClick={() => setVoucherTab("product")}
              >
                Ưu Đãi Cho Bạn
              </button>
              <button
                type="button"
                className={
                  voucherTab === "shipping" ? "active" : ""
                }
                onClick={() => setVoucherTab("shipping")}
              >
                Ưu Đãi Vận Chuyển
              </button>
            </div>

            <div className="voucher-list-container">
              {visibleCoupons
                .map((coupon) => {
                  const isSelected =
                    voucherTab === "product"
                      ? appliedProductVoucher?.id === coupon.id
                      : appliedShippingVoucher?.id === coupon.id;

                  return (
                    <div
                      key={coupon.id}
                      className={`voucher-card ${
                        isSelected ? "selected" : ""
                      }`}
                    >
                      <div className="voucher-icon">%</div>
                      <div className="voucher-info">
                        <h4>
                          Mã: {coupon.code} - Giảm{" "}
                          {Number(
                            coupon.discount_value
                          ).toLocaleString("vi-VN")}{" "}
                          {coupon.discount_type === "percent"
                            ? "%"
                            : "đ"}
                        </h4>
                        <p>
                          Đơn tối thiểu:{" "}
                          {Number(
                            coupon.min_order_value
                          ).toLocaleString("vi-VN")}{" "}
                          đ
                        </p>
                        <p>
                          Hạn sử dụng: Đến{" "}
                          {coupon.expires_at || "Không thời hạn"}
                        </p>
                      </div>
                      <div className="voucher-action">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          disabled={isApplying}
                          onChange={() => {
                            if (isSelected) {
                              if (voucherTab === "product") {
                                setAppliedProductVoucher(null);
                              } else {
                                setAppliedShippingVoucher(null);
                              }

                              return;
                            }

                            handleApplyCoupon(coupon.code);
                          }}
                        />
                      </div>
                    </div>
                  );
                })}

              {isLoadingCoupons && (
                <p className="voucher-empty">
                  Đang tải danh sách ưu đãi...
                </p>
              )}

              {!isLoadingCoupons && visibleCoupons.length === 0 && (
                <p className="voucher-empty">
                  Không có mã giảm giá phù hợp.
                </p>
              )}
            </div>

            <div className="voucher-modal-footer">
              <button
                type="button"
                className="confirm-voucher-btn"
                onClick={() => setShowVoucherModal(false)}
              >
                XÁC NHẬN
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
