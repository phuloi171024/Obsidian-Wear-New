import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiArrowRight } from "react-icons/fi";

import { API_BASE_URL } from "../config/api";

import aoPhongCotton from "../public/images/aophongcotton1.png";
import quanJeans from "../public/images/quanjeans1.png";

import "./Categories.css";

// Hai ảnh này nằm trong client/public/images nên không import
const giayTheThao = "/images/giaythethao.jpg";
const tui = "/images/tui.jpg";

const normalizeCategoryName = (name = "") =>
  name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .trim()
    .toLowerCase();

const getCategoryImage = (categoryName) => {
  const name = normalizeCategoryName(categoryName);

  if (name.includes("giay")) {
    return giayTheThao;
  }

  if (name.includes("quan")) {
    return quanJeans;
  }

  if (name.includes("tui")) {
    return tui;
  }

  if (name.includes("ao")) {
    return aoPhongCotton;
  }

  return aoPhongCotton;
};

export default function Categories({
  categories: suppliedCategories = null,
}) {
  const [fetchedCategories, setFetchedCategories] = useState([]);
  const [loading, setLoading] = useState(suppliedCategories === null);

  const categories = suppliedCategories ?? fetchedCategories;

  useEffect(() => {
    if (suppliedCategories !== null) {
      setLoading(false);
      return;
    }

    const fetchCategories = async () => {
      try {
        setLoading(true);

        const response = await fetch(`${API_BASE_URL}/categories`);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const result = await response.json();

        const categoryData = Array.isArray(result)
          ? result
          : Array.isArray(result.data)
            ? result.data
            : [];

        setFetchedCategories(categoryData);
      } catch (error) {
        console.error("Lỗi tải danh mục sản phẩm:", error);
        setFetchedCategories([]);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, [suppliedCategories]);

  if (loading) {
    return (
      <div className="categories-loading">
        Đang tải danh mục...
      </div>
    );
  }

  return (
    <section className="categories-section">
      <div className="categories-inner">
        <div className="categories-heading">
          <h2>--DANH MỤC SẢN PHẨM--</h2>
          <p>Khám phá các dòng sản phẩm nổi bật</p>
        </div>

        <div className="categories-grid">
          {categories.length > 0 ? (
            categories.slice(0, 4).map((item) => (
              <Link
                key={item.id}
                to={`/products?category_id=${item.id}`}
                className="home-category-card"
              >
                <div className="home-category-image-box">
                  <img
                    src={getCategoryImage(item.name)}
                    alt={`Danh mục ${item.name}`}
                    className="home-category-image"
                    loading="lazy"
                  />
                </div>

                <div className="category-content">
                  <h3>{item.name}</h3>

                  <span className="category-explore">
                    Khám phá ngay
                    <FiArrowRight />
                  </span>
                </div>
              </Link>
            ))
          ) : (
            <div className="categories-empty">
              Chưa có danh mục sản phẩm nào.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}