// src/services/cartService.js
import axios from "axios";
import { API_BASE_URL } from "../config/api";

const API_URL = API_BASE_URL;

// Hàm cấu hình Header chứa Token đăng nhập
const getAuthHeader = () => {
  const token = localStorage.getItem("access_token"); // Đảm bảo lúc đăng nhập em đã lưu token vào đây
  return {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  };
};

export const cartService = {
  // 1. Lấy danh sách giỏ hàng
  getCart: async () => {
    return await axios.get(`${API_URL}/cart`, getAuthHeader());
  },

  // 2. Thêm vào giỏ hàng
  addToCart: async (variantId, quantity) => {
    return await axios.post(
      `${API_URL}/cart/add`,
      {
        product_variant_id: variantId,
        quantity: quantity,
      },
      getAuthHeader(),
    );
  },

  // 3. Cập nhật số lượng
  updateQuantity: async (cartItemId, quantity) => {
    return await axios.put(
      `${API_URL}/cart/update/${cartItemId}`,
      {
        quantity: quantity,
      },
      getAuthHeader(),
    );
  },

  // 4. Xóa sản phẩm
  removeItem: async (cartItemId) => {
    return await axios.delete(
      `${API_URL}/cart/remove/${cartItemId}`,
      getAuthHeader(),
    );
  },
};
